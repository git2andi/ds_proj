# Scenario batch summary

Runs: 15 (0 errors)
Outcomes: {'majority': 7, 'successful': 2, 'unresolved': 6}

| Participants | Runs | Successful | Majority | Unresolved | Avg participant turns | Avg input tokens |
|---:|---:|---:|---:|---:|---:|---:|
| 2 | 3 | 2 | 0 | 1 | 16.3 | 10016 |
| 3 | 3 | 0 | 1 | 2 | 22.0 | 12175 |
| 4 | 3 | 0 | 1 | 2 | 27.3 | 15462 |
| 5 | 2 | 0 | 1 | 1 | 34.0 | 18428 |
| 6 | 2 | 0 | 2 | 0 | 40.5 | 21124 |
| 7 | 2 | 0 | 2 | 0 | 43.0 | 22860 |

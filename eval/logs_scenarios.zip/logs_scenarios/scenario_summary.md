# Scenario batch summary

Runs: 15 (0 errors)
Outcomes: {'majority': 2, 'successful': 2, 'unresolved': 11}

| Participants | Runs | Successful | Majority | Unresolved | Avg participant turns | Avg input tokens |
|---:|---:|---:|---:|---:|---:|---:|
| 2 | 3 | 1 | 0 | 2 | 14.0 | 12996 |
| 3 | 3 | 1 | 1 | 1 | 17.3 | 13834 |
| 4 | 3 | 0 | 0 | 3 | 31.7 | 25205 |
| 5 | 2 | 0 | 0 | 2 | 38.0 | 30420 |
| 6 | 2 | 0 | 0 | 2 | 41.5 | 34105 |
| 7 | 2 | 0 | 1 | 1 | 43.5 | 34086 |
